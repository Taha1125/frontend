import React from "react";

export default function Footer() {
  return (
    <div className="w-100">
      <p
        style={{ background: "#292a2b", fontSize: "20px", textAlign: "center" }}
        className="text-white py-4 m-0"
      >
        made by orif milod
      </p>
    </div>
  );
}

